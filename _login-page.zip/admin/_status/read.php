<?php
// Check existence of id parameter before processing further
if(isset($_GET["ID"]) && !empty(trim($_GET["ID"]))){
    // Include config file
    require_once "../../koneksi/augie.php";
    
    // Prepare a select statement
    $sql = "SELECT * FROM pembayaran WHERE ID = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["ID"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
    
            if(mysqli_num_rows($result) == 1){
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $name = $row["NAMA"];
                $kelas = $row["KELAS"];
                $induk = $row["INDUK"];
                $nisn = $row["NISN"];
                $sekolah = $row["SEKOLAH"];
                $kegiatan = $row["KEGIATAN_UJIAN_KELAS_XII_TP_2023/2024"];
                $spp2324 = $row["SPP_2023/2024"];
                $spptp2223 = $row["SPP_TP_2022/2023"];
                $spptp2122 = $row["TUNGGAKAN_PPDB_TAHUN_2021/2022"];
                $ppdb = $row["TUNGGAKAN_PPDB_TAHUN_2021/2022"];
                $tour = $row["TOUR"];
                $jumlah = $row["JUMLAH"];

            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
    
    // Close connection
    mysqli_close($conn);
} else{
    // URL doesn't contain id parameter. Redirect to error page
    header("location:error.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h1>View Record</h1>
                    </div>
                    <div class="form-group">
                        <label>Nama</label>
                        <p class="form-control-static"><?php echo $row["NAMA"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>Kelas</label>
                        <p class="form-control-static"><?php echo $row["KELAS"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>Induk</label>
                        <p class="form-control-static"><?php echo $row["INDUK"]; ?></p>
                    </div>
                    <p><a href="index.php" class="btn btn-primary">Back</a></p>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>