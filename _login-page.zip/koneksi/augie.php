<?php
$servername = "localhost";
$database = "u151762141_viera";
$username = "u151762141_viera";
$password = "Vieratale123_";
 
// Create connection

$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error){
    echo "error connection!!";
    die("Koneksi Gagal : " . $conn->connect_error);
}
//else {
//    echo "koneksi berhasil";
//}
?>